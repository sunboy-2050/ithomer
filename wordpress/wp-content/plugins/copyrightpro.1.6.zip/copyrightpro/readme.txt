=== CopyRightPro ===
Contributors: Andres Felipe Perea V.
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=RRHJ54WBU695C
Tags: copyright, images, gallery, prevent copy, text, disable right click, prevent select text, wordpress, content, protect, wp no right click plugin
Requires at least: 3.5.1
Tested up to: 3.5.1
Stable tag: 1.6

If you install CopyRightPro, your content of wordpress will be protected.

== Description ==

**CopyRightPro** is a free version of **Wp-Copyrightpro** plug-in that prevents the copying of texts and images from your blog, if you install this plug-in, your content of wordpress will be protected.

CopyrightPro is a plug-in developed by **[Wp-CopyRightPro.Com](http://wp-copyrightpro.com/)**. in order to minimize the copying of your website content. This is not a complete solution, but it will avoid 90% of attempts to copy its contents.

= This plug-in will =

* **Disable selection of text**
* **Disable right click on your Wordpress**
* **Protects from iframes** Only in wp-copyrightpro Version
* **Protects from drag and drop images** Only in wp-copyrightpro Version
* **WP-CopyRightPro doesn't have problems with search engines**


**[Official Website](http://wp-copyrightpro.com/)**
**[Support](http://wp-copyrightpro.com/)**
**[Donate](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=RRHJ54WBU695C)**


== Installation ==

This section describes how to install the plugin and get it working.

1.Download the file **CopyRightPro.zip**

2.Unzip CopyRightPro and upload the folder to the `/wp-content/plugins/` directory.

3.Enter in your admin panel of wordpress and activate the plugin.

**Now your content of wordpress will be protected**


= spanish Installation =

1.Descargar el archivo **CopyRightPro.zip** 

2.Descomprime **CopyRightPro** y sube la carpeta a tu servidor en el directorio `/wp-content/plugins/` 

3.Ingresa en tu panel de administracion de wordpress y activa el plugin. 

**Ahora el contenido de tu wordpress estara protegido**


== Screenshots ==
1. 
2. 

== Frequently Asked Questions ==

= CopyRightPro is bad for the SEO? =
This plug-in is developed in PHP and javascript, for this reason the plug-in does not affect search engines, it only affects the user's browser that tries to copy your content.

= CopyrightPro detects the hotlink? =
When activating 100% of the protections, in less than a week, CopyRightPro can reveal sites that are using your images, just by logging into Google.com images section type this (site:yoursite.com) and google will show the sites that are using your images.

**For questions, suggestions, please enter our Official Site [here](http://wp-copyrightpro.com/).**

== Changelog ==

= 1.0 =
* Firt version of CopyRightPro

= 1.1 =
* For wordpress 3.3.2


= 1.2 =
* For wordpress 3.4.2

= 1.3 =
* Firefox problem solved

= 1.4 =
* For Wordpress 3.5


= 1.5 =
* For Wordpress 3.5.1

= 1.6 =
* For Wordpress 3.5.1 last Version